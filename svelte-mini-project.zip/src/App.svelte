<script>
  let count = 0;
  function increment() {
    count += 1;
  }
</script>

<main>
  <h1>Лічильник</h1>
  <p>Поточне значення: {count}</p>
  <button on:click={increment}>Додати 1</button>
</main>

<style>
  main {
    text-align: center;
    padding: 2em;
    font-family: Arial, sans-serif;
  }

  button {
    margin-top: 1em;
    padding: 0.5em 1em;
    font-size: 1em;
    cursor: pointer;
  }
</style>
